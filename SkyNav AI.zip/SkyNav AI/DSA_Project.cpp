#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <iomanip>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
using namespace std;

//-----------------------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------
class Flight
{
public:
    string origin;
    string destination;
    string travel_date;
    string flying_time;
    string landing_time;
    int ticket_price;
    string airline_name;

    Flight() {}

    // Parameterized constructor
    Flight(string origin, string destination, string travel_date,
        string flying_time, string landing_time, int ticket_price,
        string airline_name)
    {
        this->origin = origin;
        this->destination = destination;
        this->travel_date = travel_date;
        this->flying_time = flying_time;
        this->landing_time = landing_time;
        this->ticket_price = ticket_price;
        this->airline_name = airline_name;
    }

    // Destructor
    ~Flight() {}

    // Member functions to display the flight details
    void displayFlightDetails()
    {
        cout << "Origin: " << origin
            << ", Destination: " << destination
            << ", Travel Date: " << travel_date
            << ", Flying Time: " << flying_time
            << ", Landing Time: " << landing_time
            << ", Ticket Price: " << ticket_price
            << ", Airline: " << airline_name << endl;
    }
    bool isSameDay(const string& date) {
        return travel_date == date;
    }

    int getLandingMinutes() {
        int hour, minute;
        sscanf_s(landing_time.c_str(), "%d:%d", &hour, &minute);
        return hour * 60 + minute;
    }

    int getFlyingMinutes() {
        int hour, minute;
        sscanf_s(flying_time.c_str(), "%d:%d", &hour, &minute);
        return hour * 60 + minute;
    }

    static bool isLayoverValid(int landingMinutes, int nextFlightFlyingMinutes) {
        return nextFlightFlyingMinutes > landingMinutes; // Ensures the layover is valid
    }

    static int getTimeDifference(int time1, int time2) {
        return time2 - time1; // Returns the difference in minutes
    }

    int getFlightDuration() {
        int landingMinutes = getLandingMinutes();
        int flyingMinutes = getFlyingMinutes();
        return abs(landingMinutes - flyingMinutes); // Use abs to ignore the negative sign
    }
    std::string getTimeDifference(const std::string& flyingTime, const std::string& landingTime)
    {
        int flyingHour, flyingMinute;
        int landingHour, landingMinute;

        // Parse the flying and landing times (assuming correct format "HH:MM")
        sscanf_s(flyingTime.c_str(), "%d:%d", &flyingHour, &flyingMinute);
        sscanf_s(landingTime.c_str(), "%d:%d", &landingHour, &landingMinute);

        // Calculate the time difference in minutes
        int flyingTotalMinutes = flyingHour * 60 + flyingMinute;
        int landingTotalMinutes = landingHour * 60 + landingMinute;

        int durationMinutes = landingTotalMinutes - flyingTotalMinutes;

        // Convert duration to hours and minutes
        int hours = durationMinutes / 60;
        int minutes = durationMinutes % 60;

        // Return formatted string
        return std::to_string(hours) + " hours " + std::to_string(minutes) + " minutes";
    }
};
//-----------------------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------
class Hotel
{
public:
    string city;
    int price_per_day;

    Hotel() {}

    // Parameterized constructor
    Hotel(string city, int price_per_day)
    {
        this->city = city;
        this->price_per_day = price_per_day;
    }

    // Destructor
    ~Hotel() {}

    // Member function to display hotel details
    void displayHotelDetails()
    {
        cout << "City: " << city
            << ", Hotel Price per Day: " << price_per_day << endl;
    }
};
//-----------------------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------
class Node
{
public:
    Flight flightData;
    Node* next;
    Node() {}
    Node(Flight f) : flightData(f), next(nullptr) {}
};

class Adjlist
{
public:
    Node* head;

    Adjlist() : head(nullptr) {}

    void insert(Flight flight)
    {
        Node* temp = new Node(flight);
        if (head == nullptr)
        {
            head = temp;
        }
        else
        {
            Node* curr = head;
            while (curr->next != nullptr)
            {
                curr = curr->next;
            }
            curr->next = temp;
        }
    }

    void print()
    {
        Node* temp = head;
        while (temp != nullptr)
        {
            cout << "Origin: " << temp->flightData.origin
                << " | Destination: " << temp->flightData.destination
                << " | Travel Date: " << temp->flightData.travel_date
                << " | Flying Time: " << temp->flightData.flying_time
                << " | Landing Time: " << temp->flightData.landing_time
                << " | Ticket Price: " << temp->flightData.ticket_price
                << " | Airline: " << temp->flightData.airline_name << endl;
            temp = temp->next;
        }
    }

    bool isEmpty()
    {
        return head == nullptr;
    }
};

class Graph
{
public:
    int maxVertices;
    Adjlist* adjLists;
    Hotel* hotels;   // Array of Hotel objects
    int hotelCount;
    string* cityNames;  // Array to store city names for reference

    Graph(int size) : maxVertices(size), hotelCount(0)
    {
        adjLists = new Adjlist[size];
        hotels = new Hotel[size];
        cityNames = new string[size];
    }

    // Add hotel information
    void addHotel(string city, int price_per_day)
    {
        if (hotelCount >= maxVertices)
        {
            cout << "Error: Maximum number of cities reached." << endl;
            return;
        }
        cityNames[hotelCount] = city;
        hotels[hotelCount++] = Hotel(city, price_per_day);
    }

    // Find the index of a city by name
    int findCityIndex(string name)
    {
        for (int i = 0; i < hotelCount; i++)
        {
            if (cityNames[i] == name)
            {
                return i;
            }
        }
        return -1; // City not found
    }

    // Insert a flight between two cities
    void insertFlight(int originIndex, int destinationIndex, Flight flight)
    {
        if (originIndex < 0 || destinationIndex < 0 ||
            originIndex >= maxVertices || destinationIndex >= maxVertices)
        {
            cout << "Error: Invalid city indices." << endl;
            return;
        }
        adjLists[originIndex].insert(flight);
        adjLists[destinationIndex].insert(flight); // assuming bi-directional flights
    }

    void generateSubgraph(int cityIndex, Graph& subgraph)
    {
        for (int i = 0; i < maxVertices; i++)
        {
            if (i == cityIndex)
            {
                continue;
            }

            for (Node* temp = adjLists[i].head; temp != nullptr; temp = temp->next)
            {
                if (temp->flightData.destination == cityNames[cityIndex])
                {
                    subgraph.insertFlight(i + 1, cityIndex + 1, temp->flightData);

                    // Print the details of the flight being added to the subgraph
                    cout << "Flight added to subgraph: "
                        << cityNames[i] << " -> "
                        << temp->flightData.destination
                        << " (Cost : " << temp->flightData.ticket_price << ")"
                        << std::endl;
                }
            }
        }

        cout << "\n" << endl;
    }

    // Show all cities and flights between them
    void showGraph()
    {
        for (int i = 0; i < hotelCount; ++i)
        {
            cout << "City: " << hotels[i].city << " | Hotel Charge per Day: " << hotels[i].price_per_day << endl;
            adjLists[i].print();
            cout << endl;
        }
    }

    void dijkstra(const char* startCity, const char* endCity, bool byCost)
    {
        int startIndex = findCityIndex(startCity);
        int endIndex = findCityIndex(endCity);

        if (startIndex == -1 || endIndex == -1)
        {
            if (startIndex == -1)
            {
                cout << "\n Error! \n Unable to find your origin city :(  " << endl << startCity << endl;
                cout << " Please try again with given city names \n Thank you :) " << endl;
                return;
            }
            else
            {
                cout << "\n Error! \n Unable to find your destination city :( " << endl << endCity << endl;
                cout << " Please try again with given city names \n Thank you :) " << endl;
                return;
            }
        }

        const int INF = 1e9;        // For larger value 10^9

        // Dynamically allocate arrays based on maxVertices
        int* dist = new int[maxVertices];       // To store the shortest distance to each city
        int* prev = new int[maxVertices];       // To store the previous city in the shortest path
        bool* visited = new bool[maxVertices];  // To track visited cities

        // Initialize arrays
        for (int i = 0; i < maxVertices; i++)
        {
            dist[i] = INF;          // First the distance is infinity
            prev[i] = -1;           // No previous node initially
            visited[i] = false;     // None of the nodes are visited yet
        }
        dist[startIndex] = 0;

        while (true)
        {
            int minDist = INF, u = -1;

            // Find the unvisited city with the smallest distance
            for (int i = 0; i < maxVertices; i++)
            {
                if (!visited[i] && dist[i] < minDist)
                {
                    minDist = dist[i];
                    u = i;
                }
            }

            if (u == -1 || u == endIndex) break; // No more reachable cities or reached destination

            visited[u] = true;

            // Explore neighbors from adjacency list
            Node* neighbor = adjLists[u].head;  // Assuming adjLists stores adjacency list heads
            while (neighbor)
            {
                Flight flight = neighbor->flightData;  // Extract flight details
                int v = findCityIndex(flight.destination);
                int weight = byCost ? flight.ticket_price :
                    atoi(flight.landing_time.c_str()) - atoi(flight.flying_time.c_str());

                // Relax edge
                if (!visited[v] && dist[u] + weight < dist[v])
                {
                    dist[v] = dist[u] + weight;
                    prev[v] = u;
                }
                neighbor = neighbor->next;
            }
        }

        // Display Results
        if (dist[endIndex] == INF)
        {
            cout << "No path found from " << startCity << " to " << endCity << "." << endl;
        }
        else
        {
            cout << "Shortest path " << (byCost ? "by cost" : "by time") << " is " << dist[endIndex] << "." << endl;

            // Dynamically allocate memory for the path
            int* path = new int[maxVertices];
            int pathLen = 0;

            // Backtrack to display the path
            for (int at = endIndex; at != -1; at = prev[at])
            {
                path[pathLen++] = at;
            }

            cout << "Path: ";
            for (int i = pathLen - 1; i >= 0; i--)
            {
                cout << cityNames[path[i]];
                if (i > 0) cout << " -> ";
            }
            cout << endl;

            // Free the path memory
            delete[] path;
        }

        // Free the dynamically allocated arrays
        delete[] dist;
        delete[] prev;
        delete[] visited;

    }

    void visualizeDijkstra(int* dist, int* prev, bool* visited, int startIndex, int endIndex)
    {
        const int WINDOW_WIDTH = 800;
        const int WINDOW_HEIGHT = 600;
        const int NODE_RADIUS = 20;

        sf::RenderWindow window(sf::VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), "Dijkstra Visualization");

        // Generate random positions for cities
        sf::Vector2f* positions = new sf::Vector2f[maxVertices];
        for (int i = 0; i < maxVertices; i++)
        {
            positions[i] = sf::Vector2f(rand() % (WINDOW_WIDTH - 100) + 50, rand() % (WINDOW_HEIGHT - 100) + 50);
        }

        while (window.isOpen())
        {
            sf::Event event;
            while (window.pollEvent(event))
            {
                if (event.type == sf::Event::Closed)
                    window.close();
            }

            window.clear(sf::Color::White);

            // Draw edges
            // Draw edges
            for (int u = 0; u < maxVertices; u++)
            {
                Node* neighbor = adjLists[u].head;
                while (neighbor)
                {
                    int v = findCityIndex(neighbor->flightData.destination);

                    // Check if this edge is part of the shortest path
                    bool isPathEdge = false;

                    // Traverse the path from endIndex back to startIndex
                    int current = endIndex;
                    while (current != -1)
                    {
                        int previous = prev[current]; // Get predecessor
                        if (previous == -1)
                            break;

                        // Check if edge (u, v) is in the path
                        if ((current == u && previous == v) || (current == v && previous == u))
                        {
                            isPathEdge = true;
                            break;
                        }
                        current = previous; // Move backward in the path
                    }

                    // Set edge color based on path status
                    sf::Color edgeColor = isPathEdge ? sf::Color::Green : sf::Color::Black;
                    sf::Vertex line[] = {
                        sf::Vertex(positions[u], edgeColor),
                        sf::Vertex(positions[v], edgeColor)
                    };
                    window.draw(line, 2, sf::Lines);

                    neighbor = neighbor->next;
                }
            }


            // Draw nodes
            for (int i = 0; i < maxVertices; i++)
            {
                sf::CircleShape node(NODE_RADIUS);
                node.setPosition(positions[i].x - NODE_RADIUS, positions[i].y - NODE_RADIUS);

                // Node colors
                if (visited[i])
                {
                    node.setFillColor(sf::Color::Red); // Evaluated node
                }
                else
                {
                    node.setFillColor(sf::Color::Blue); // Non-evaluated node
                }

                if (i == startIndex)
                    node.setFillColor(sf::Color::Green); // Start node
                if (i == endIndex)
                    node.setFillColor(sf::Color::Yellow); // End node

                window.draw(node);

                // Display city names
                sf::Font font;
                if (!font.loadFromFile("C:\Visual Studio kaam\FLIGHT SIMULATION-23i-2044,23i-2071,23i--2103\\PlayfairDisplay-Regular.ttf"))
                {
                    std::cerr << "Error loading font!" << std::endl;
                    return;
                }
                sf::Text cityName(cityNames[i], font, 12);
                cityName.setPosition(positions[i].x - 20, positions[i].y - 40);
                cityName.setFillColor(sf::Color::Black);
                window.draw(cityName);
            }

            // Highlight shortest path
            int* path = new int[maxVertices];
            int pathLen = 0;
            for (int at = endIndex; at != -1; at = prev[at])
            {
                path[pathLen++] = at;
            }
            for (int i = pathLen - 1; i > 0; i--)
            {
                int u = path[i];
                int v = path[i - 1];
                sf::Vertex line[] = {
                    sf::Vertex(positions[u], sf::Color::Green),
                    sf::Vertex(positions[v], sf::Color::Green)
                };
                window.draw(line, 2, sf::Lines);
            }

            window.display();
            delete[] path;
        }

        delete[] positions;
    }


    void BookFlight(string start, string end, string date)
    {
        int originindex = findCityIndex(start);     //agr yeh -1 na hua yhen woh city exist krta hai
        int destindex = findCityIndex(end);

        if (originindex == -1 || destindex == -1)
        {
            if (originindex == -1)
            {
                cout << "\n Error! \n Unable to find your origin city :(  " << endl << start << endl;
                cout << " Please try again with given city names \n Thank you :) " << endl;
                return;
            }
            else
            {
                cout << "\n Error! \n Unable to find your destination city :( " << endl << end << endl;
                cout << " Please try again with given city names \n Thank you :) " << endl;
                return;
            }
        }

        //For direct flights checking uss ke liye 
        Node* directFlight = adjLists[originindex].head;
        bool found = false;
        while (directFlight != nullptr)
        {
            if (directFlight->flightData.destination == end && directFlight->flightData.travel_date == date)
            {
                cout << "Direct flight found:" << endl;
                directFlight->flightData.displayFlightDetails();
                found = true;
                break;
            }
            directFlight = directFlight->next;
        }

        if (found) return;

        // Check connecting flights
        Node* connection = adjLists[originindex].head;
        while (connection != nullptr)
        {
            int layoverIndex = findCityIndex(connection->flightData.destination);

            if (layoverIndex != -1 && connection->flightData.travel_date == date)
            {
                Node* layoverFlight = adjLists[layoverIndex].head;
                while (layoverFlight != nullptr)
                {
                    if (layoverFlight->flightData.destination == end && layoverFlight->flightData.travel_date == date)
                    {
                        cout << "Connecting flights found:" << endl;
                        connection->flightData.displayFlightDetails();
                        layoverFlight->flightData.displayFlightDetails();
                        return;
                    }
                    layoverFlight = layoverFlight->next;
                }
            }
            connection = connection->next;
        }

        cout << "No flights available for the specified route and date." << endl;
    }

    void SearchFlight(string origin, string destination, string date)
    {
        int originindex = findCityIndex(origin);     //agr yeh -1 na hua yhen woh city exist krta hai
        int destindex = findCityIndex(destination);

        if (originindex == -1 || destindex == -1)
        {
            if (originindex == -1)
            {
                cout << "\n Error! \n Unable to find your origin city :(  " << endl << origin << endl;
                cout << " Please try again with given city names \n Thank you :) " << endl;
                return;
            }
            else
            {
                cout << "\n Error! \n Unable to find your destination city :( " << endl << destination << endl;
                cout << " Please try again with given city names \n Thank you :) " << endl;
                return;
            }
        }

        //For direct flights checking uss ke liye 
        Node* directFlight = adjLists[originindex].head;
        bool found = false;
        while (directFlight != nullptr)
        {
            if (directFlight->flightData.destination == destination && directFlight->flightData.travel_date == date)
            {
                cout << "Direct flight found:" << endl;
                directFlight->flightData.displayFlightDetails();
                found = true;
                break;
            }
            directFlight = directFlight->next;
        }

        if (found) return;

        // Check connecting flights
        Node* connection = adjLists[originindex].head;
        while (connection != nullptr)
        {
            int layoverIndex = findCityIndex(connection->flightData.destination);

            if (layoverIndex != -1 && connection->flightData.travel_date == date)
            {
                Node* layoverFlight = adjLists[layoverIndex].head;
                while (layoverFlight != nullptr)
                {
                    if (layoverFlight->flightData.destination == destination && layoverFlight->flightData.travel_date == date)
                    {
                        cout << "Connecting flights found:" << endl;
                        connection->flightData.displayFlightDetails();
                        layoverFlight->flightData.displayFlightDetails();
                        return;
                    }
                    layoverFlight = layoverFlight->next;
                }
            }
            connection = connection->next;
        }

        cout << "No flights available for the specified route and date." << endl;
    }
    void graphicsForSelectedFlight(const char* start, const char* end, const char* date)
    {
        // Find indices of the start and end cities
        int originIndex = findCityIndex(start);
        int destIndex = findCityIndex(end);

        if (originIndex == -1 || destIndex == -1)
        {
            cout << "Error! Unable to find the specified cities in the system." << endl;
            return;
        }

        // SFML Setup
        sf::RenderWindow window(sf::VideoMode(800, 600), "Flight Booking Visualization");
        sf::Font font;
        if (!font.loadFromFile("C:\Visual Studio kaam\FLIGHT SIMULATION-23i-2044,23i-2071,23i--2103\\PlayfairDisplay-Regular.ttf"))
        {
            cerr << "Error: Unable to load font." << endl;
            return;
        }

        // City Nodes and Labels
        sf::CircleShape startNode(12), destNode(12), layoverNode(12);
        sf::Text startLabel, destLabel, layoverLabel, tooltipText;

        // Position of cities (hardcoded for simplicity)
        sf::Vector2f startCityPos(200, 300);
        sf::Vector2f endCityPos(600, 300);
        sf::Vector2f layoverCityPos(400, 300); // Midpoint for layover city

        // Setup the starting city node and label
        startNode.setFillColor(sf::Color::Green);
        startNode.setPosition(startCityPos);
        startLabel.setFont(font);
        startLabel.setString(start);
        startLabel.setCharacterSize(14);
        startLabel.setFillColor(sf::Color::White);
        startLabel.setPosition(startCityPos.x - 20, startCityPos.y - 30);

        // Setup the destination city node and label
        destNode.setFillColor(sf::Color::Green);
        destNode.setPosition(endCityPos);
        destLabel.setFont(font);
        destLabel.setString(end);
        destLabel.setCharacterSize(14);
        destLabel.setFillColor(sf::Color::White);
        destLabel.setPosition(endCityPos.x - 20, endCityPos.y - 30);

        bool directFlightFound = false;
        bool connectingFlightFound = false;

        Node* directFlight = adjLists[originIndex].head;
        Node* connection = adjLists[originIndex].head;

        while (window.isOpen())
        {
            sf::Event event;
            while (window.pollEvent(event))
            {
                if (event.type == sf::Event::Closed)
                    window.close();
            }

            window.clear();

            // Draw start and destination cities
            window.draw(startNode);
            window.draw(startLabel);
            window.draw(destNode);
            window.draw(destLabel);

            // Check for direct flights
            while (directFlight != nullptr)
            {
                if (directFlight->flightData.destination == end && directFlight->flightData.travel_date == date)
                {
                    // Draw direct flight line
                    sf::Vertex directLine[] = {
                        sf::Vertex(sf::Vector2f(startCityPos.x + 12, startCityPos.y + 12), sf::Color::White),
                        sf::Vertex(sf::Vector2f(endCityPos.x + 12, endCityPos.y + 12), sf::Color::White)
                    };
                    window.draw(directLine, 2, sf::Lines);
                    directFlightFound = true;
                    break;
                }
                directFlight = directFlight->next;
            }

            // Check for connecting flights if no direct flight is found
            if (!directFlightFound)
            {
                while (connection != nullptr)
                {
                    int layoverIndex = findCityIndex(connection->flightData.destination);
                    if (layoverIndex != -1 && connection->flightData.travel_date == date)
                    {
                        Node* layoverFlight = adjLists[layoverIndex].head;
                        while (layoverFlight != nullptr)
                        {
                            if (layoverFlight->flightData.destination == end && layoverFlight->flightData.travel_date == date)
                            {
                                // Draw layover city and label
                                layoverNode.setFillColor(sf::Color::Yellow);
                                layoverNode.setPosition(layoverCityPos);
                                layoverLabel.setFont(font);
                                layoverLabel.setString(connection->flightData.destination);
                                layoverLabel.setCharacterSize(14);
                                layoverLabel.setFillColor(sf::Color::White);
                                layoverLabel.setPosition(layoverCityPos.x - 20, layoverCityPos.y - 30);

                                window.draw(layoverNode);
                                window.draw(layoverLabel);

                                // Draw lines for layover flight
                                sf::Vertex layoverLine1[] = {
                                    sf::Vertex(sf::Vector2f(startCityPos.x + 12, startCityPos.y + 12), sf::Color::White),
                                    sf::Vertex(sf::Vector2f(layoverCityPos.x + 12, layoverCityPos.y + 12), sf::Color::White)
                                };
                                sf::Vertex layoverLine2[] = {
                                    sf::Vertex(sf::Vector2f(layoverCityPos.x + 12, layoverCityPos.y + 12), sf::Color::White),
                                    sf::Vertex(sf::Vector2f(endCityPos.x + 12, endCityPos.y + 12), sf::Color::White)
                                };

                                window.draw(layoverLine1, 2, sf::Lines);
                                window.draw(layoverLine2, 2, sf::Lines);

                                connectingFlightFound = true;
                                break;
                            }
                            layoverFlight = layoverFlight->next;
                        }
                    }
                    if (connectingFlightFound) break;
                    connection = connection->next;
                }
            }

            // Handle mouse hover and display tooltip
            sf::Vector2i mousePos = sf::Mouse::getPosition(window);
            if (startNode.getGlobalBounds().contains(sf::Vector2f(mousePos)))
            {
                tooltipText.setFont(font);
                tooltipText.setString("Start City: " + std::string(start) + "\nDirect Flight Available: " + (directFlightFound ? "Yes" : "No"));
                tooltipText.setCharacterSize(14);
                tooltipText.setFillColor(sf::Color::White);
                tooltipText.setPosition(mousePos.x + 10, mousePos.y + 10);
                window.draw(tooltipText);
            }
            else if (destNode.getGlobalBounds().contains(sf::Vector2f(mousePos)))
            {
                tooltipText.setFont(font);
                tooltipText.setString("Destination City: " + std::string(end) + "\nDirect Flight Available: " + (directFlightFound ? "Yes" : "No"));
                tooltipText.setCharacterSize(14);
                tooltipText.setFillColor(sf::Color::White);
                tooltipText.setPosition(mousePos.x + 10, mousePos.y + 10);
                window.draw(tooltipText);
            }
            else if (directFlightFound && mousePos.x >= startCityPos.x && mousePos.x <= endCityPos.x &&
                mousePos.y >= startCityPos.y && mousePos.y <= endCityPos.y)
            {
                tooltipText.setFont(font);
                tooltipText.setString("Flight Details: Direct flight from " + std::string(start) + " to " + std::string(end) + "\nDate: " + std::string(date));
                tooltipText.setCharacterSize(14);
                tooltipText.setFillColor(sf::Color::White);
                tooltipText.setPosition(mousePos.x + 10, mousePos.y + 10);
                window.draw(tooltipText);
            }

            // Display a message if no flights are found
            if (!directFlightFound && !connectingFlightFound)
            {
                sf::Text noFlightMessage;
                noFlightMessage.setFont(font);
                noFlightMessage.setString("No flights available.");
                noFlightMessage.setCharacterSize(18);
                noFlightMessage.setFillColor(sf::Color::Red);
                noFlightMessage.setPosition(300, 500);
                window.draw(noFlightMessage);
            }

            window.display();
        }
    }


    void graphicsForGraphWithTooltips(Graph& g1, string Hotel_city[], Flight flights[], int flightCount, int cityCount)
    {
        // SFML Setup
        sf::RenderWindow window(sf::VideoMode(1200, 800), "Graph Visualization with Tooltips");
        sf::Font font;
        if (!font.loadFromFile("C:\Visual Studio kaam\FLIGHT SIMULATION - 23i - 2044, 23i - 2071, 23i--2103\\PlayfairDisplay - Regular.ttf"))
        {
            std::cerr << "Error: Unable to load font." << std::endl;
            return;
        }

        sf::Text tooltipText;
        tooltipText.setFont(font);
        tooltipText.setCharacterSize(12);
        tooltipText.setFillColor(sf::Color::White);

        bool showTooltip = false;
        sf::Vector2f tooltipPosition;

        // Define city nodes and labels
        sf::CircleShape cityNode[11];
        sf::Text cityLabel[11];

        // Position of city nodes (hardcoded)
        sf::Vector2f nodePositions[11] = {
            {100, 100}, {100, 600}, {700, 600}, {1100, 350}, {500, 300},
            {100, 350}, {300, 450}, {800, 450}, {650, 150}, {1100, 600},
            {1100, 100}
        };

        // Price-to-color mapping
        auto getPriceColor = [](int price) -> sf::Color {
            if (price < 15000) return sf::Color::Green;  // Low price
            if (price < 30000) return sf::Color::Yellow; // Medium price
            return sf::Color::Red;                       // High price
            };

        while (window.isOpen())
        {
            sf::Event event;
            while (window.pollEvent(event))
            {
                if (event.type == sf::Event::Closed)
                    window.close();
            }

            window.clear();

            // Draw edges (lines representing flights)
            for (int i = 0; i < flightCount; i++)
            {
                int originIndex = g1.findCityIndex(flights[i].origin);
                int destIndex = g1.findCityIndex(flights[i].destination);

                if (originIndex != -1 && destIndex != -1)
                {
                    sf::Vertex line[] = {
                        sf::Vertex(nodePositions[originIndex], sf::Color::White),
                        sf::Vertex(nodePositions[destIndex], sf::Color::White)
                    };
                    window.draw(line, 2, sf::Lines);

                    // Detect mouse hover over flight line
                    sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                    sf::Vector2f originPos = nodePositions[originIndex];
                    sf::Vector2f destPos = nodePositions[destIndex];

                    // Calculate line hover bounds
                    sf::FloatRect flightBounds(
                        std::min(originPos.x, destPos.x) - 5,
                        std::min(originPos.y, destPos.y) - 5,
                        std::abs(destPos.x - originPos.x) + 10,
                        std::abs(destPos.y - originPos.y) + 10
                    );

                    if (flightBounds.contains(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y)))
                    {
                        showTooltip = true;
                        tooltipPosition = sf::Vector2f(mousePos.x, mousePos.y);

                        // Set tooltip text to flight details
                        std::ostringstream flightDetails;
                        flightDetails << "Flight: " << flights[i].origin << " -> " << flights[i].destination << "\n"
                            << "Date: " << flights[i].travel_date << "\n"
                            << "Time: " << flights[i].flying_time << " -> " << flights[i].landing_time << "\n"
                            << "Price: $" << flights[i].ticket_price << "\n"
                            << "Airline: " << flights[i].airline_name;

                        tooltipText.setString(flightDetails.str());
                    }
                }
            }

            // Draw nodes for cities
            for (int i = 0; i < cityCount; i++)
            {
                cityNode[i].setRadius(12);
                cityNode[i].setFillColor(getPriceColor(flights[i % flightCount].ticket_price)); // Dynamic color
                cityNode[i].setPosition(nodePositions[i]);
                cityNode[i].setOutlineColor(sf::Color::Black);
                cityNode[i].setOutlineThickness(2);
                window.draw(cityNode[i]);

                // Draw city name
                cityLabel[i].setFont(font);
                cityLabel[i].setString(Hotel_city[i]);
                cityLabel[i].setCharacterSize(14);
                cityLabel[i].setFillColor(sf::Color::White);

                sf::FloatRect cityNameBounds = cityLabel[i].getLocalBounds();
                cityLabel[i].setPosition(
                    nodePositions[i].x + 30 - cityNameBounds.width / 2,
                    nodePositions[i].y - cityNameBounds.height - 5
                );
                window.draw(cityLabel[i]);
            }

            // Display tooltip if hovering
            if (showTooltip)
            {
                sf::RectangleShape tooltipBackground;
                sf::FloatRect tooltipBounds = tooltipText.getLocalBounds();

                tooltipBackground.setSize(sf::Vector2f(tooltipBounds.width + 10, tooltipBounds.height + 10));
                tooltipBackground.setFillColor(sf::Color(0, 0, 0, 150)); // Semi-transparent black
                tooltipBackground.setPosition(tooltipPosition.x + 10, tooltipPosition.y + 10);

                tooltipText.setPosition(tooltipPosition.x + 15, tooltipPosition.y + 15);

                window.draw(tooltipBackground);
                window.draw(tooltipText);
            }

            window.display();
        }
    }
    void FilterbyTransit(string start, string end, string date, string airline, string transitCity)
    {
        int originindex = findCityIndex(start);     //agr yeh -1 na hua yhen woh city exist krta hai
        int destindex = findCityIndex(end);

        if (originindex == -1 || destindex == -1)
        {
            if (originindex == -1)
            {
                cout << "\n Error! \n Unable to find your origin city :(  " << endl << start << endl;
                cout << " Please try again with given city names \n Thank you :) " << endl;
                return;
            }
            else
            {
                cout << "\n Error! \n Unable to find your destination city :( " << endl << end << endl;
                cout << " Please try again with given city names \n Thank you :) " << endl;
                return;
            }
        }

        //For direct flights checking uss ke liye 
        Node* directFlight = adjLists[originindex].head;
        bool found = false;
        while (directFlight != nullptr)
        {
            if (directFlight->flightData.destination == transitCity && directFlight->flightData.travel_date == date && directFlight->flightData.airline_name == airline)
            {
                cout << "Direct flight found:" << endl;
                directFlight->flightData.displayFlightDetails();
                found = true;
                break;
            }
            directFlight = directFlight->next;
        }

        if (found) return;

        // Check connecting flights
        Node* connection = adjLists[originindex].head;
        while (connection != nullptr)
        {
            int layoverIndex = findCityIndex(connection->flightData.destination);

            if (layoverIndex != -1 && connection->flightData.travel_date == date)
            {
                Node* layoverFlight = adjLists[layoverIndex].head;
                while (layoverFlight != nullptr)
                {
                    if (layoverFlight->flightData.destination == end && layoverFlight->flightData.travel_date == date && layoverFlight->flightData.origin == transitCity)
                    {
                        cout << "Connecting flights found:" << endl;
                        connection->flightData.displayFlightDetails();
                        layoverFlight->flightData.displayFlightDetails();
                        return;
                    }
                    layoverFlight = layoverFlight->next;
                }
            }
            connection = connection->next;
        }

        cout << "No flights available for the specified route and date." << endl;
    }


    void graphicsForTransit(const char* start, const char* end, const char* ddate, const char* airline, const char* transitcity)
    {
        // Find indices of the start and end cities
        int originIndex = findCityIndex(start);
        int destIndex = findCityIndex(end);

        if (originIndex == -1 || destIndex == -1)
        {
            cout << "Error! Unable to find the specified cities in the system." << endl;
            return;
        }

        // SFML Setup
        sf::RenderWindow window(sf::VideoMode(800, 600), "Flight Booking Visualization");
        sf::Font font;
        if (!font.loadFromFile("C:\Visual Studio kaam\FLIGHT SIMULATION - 23i - 2044, 23i - 2071, 23i--2103\\PlayfairDisplay - Regular.ttf"))
        {
            cerr << "Error: Unable to load font." << endl;
            return;
        }

        // City Nodes and Labels
        sf::CircleShape startNode(12), destNode(12), layoverNode(12);
        sf::Text startLabel, destLabel, layoverLabel, tooltipText;

        // Position of cities (hardcoded for simplicity)
        sf::Vector2f startCityPos(200, 300);
        sf::Vector2f endCityPos(600, 300);
        sf::Vector2f layoverCityPos(400, 300); // Midpoint for layover city

        // Setup the starting city node and label
        startNode.setFillColor(sf::Color::Green);
        startNode.setPosition(startCityPos);
        startLabel.setFont(font);
        startLabel.setString(start);
        startLabel.setCharacterSize(14);
        startLabel.setFillColor(sf::Color::White);
        startLabel.setPosition(startCityPos.x - 20, startCityPos.y - 30);

        // Setup the destination city node and label
        destNode.setFillColor(sf::Color::Green);
        destNode.setPosition(endCityPos);
        destLabel.setFont(font);
        destLabel.setString(end);
        destLabel.setCharacterSize(14);
        destLabel.setFillColor(sf::Color::White);
        destLabel.setPosition(endCityPos.x - 20, endCityPos.y - 30);

        bool directFlightFound = false;
        bool connectingFlightFound = false;

        Node* directFlight = adjLists[originIndex].head;
        Node* connection = adjLists[originIndex].head;

        while (window.isOpen())
        {
            sf::Event event;
            while (window.pollEvent(event))
            {
                if (event.type == sf::Event::Closed)
                    window.close();
            }

            window.clear();

            // Draw start and destination cities
            window.draw(startNode);
            window.draw(startLabel);
            window.draw(destNode);
            window.draw(destLabel);

            // Check for direct flights
            while (directFlight != nullptr)
            {
                if (directFlight->flightData.destination == transitcity && directFlight->flightData.travel_date == ddate && directFlight->flightData.airline_name == airline)
                {
                    // Draw direct flight line
                    sf::Vertex directLine[] = {
                        sf::Vertex(sf::Vector2f(startCityPos.x + 12, startCityPos.y + 12), sf::Color::White),
                        sf::Vertex(sf::Vector2f(endCityPos.x + 12, endCityPos.y + 12), sf::Color::White)
                    };
                    window.draw(directLine, 2, sf::Lines);
                    directFlightFound = true;
                    break;
                }
                directFlight = directFlight->next;
            }

            // Check for connecting flights if no direct flight is found
            if (!directFlightFound)
            {
                while (connection != nullptr)
                {
                    int layoverIndex = findCityIndex(connection->flightData.destination);
                    if (layoverIndex != -1 && connection->flightData.travel_date == ddate)
                    {
                        Node* layoverFlight = adjLists[layoverIndex].head;
                        while (layoverFlight != nullptr)
                        {
                            if (layoverFlight->flightData.destination == end && layoverFlight->flightData.travel_date == ddate && layoverFlight->flightData.origin == transitcity)
                            {
                                // Draw layover city and label
                                layoverNode.setFillColor(sf::Color::Yellow);
                                layoverNode.setPosition(layoverCityPos);
                                layoverLabel.setFont(font);
                                layoverLabel.setString(connection->flightData.destination);
                                layoverLabel.setCharacterSize(14);
                                layoverLabel.setFillColor(sf::Color::White);
                                layoverLabel.setPosition(layoverCityPos.x - 20, layoverCityPos.y - 30);

                                window.draw(layoverNode);
                                window.draw(layoverLabel);

                                // Draw lines for layover flight
                                sf::Vertex layoverLine1[] = {
                                    sf::Vertex(sf::Vector2f(startCityPos.x + 12, startCityPos.y + 12), sf::Color::White),
                                    sf::Vertex(sf::Vector2f(layoverCityPos.x + 12, layoverCityPos.y + 12), sf::Color::White)
                                };
                                sf::Vertex layoverLine2[] = {
                                    sf::Vertex(sf::Vector2f(layoverCityPos.x + 12, layoverCityPos.y + 12), sf::Color::White),
                                    sf::Vertex(sf::Vector2f(endCityPos.x + 12, endCityPos.y + 12), sf::Color::White)
                                };

                                window.draw(layoverLine1, 2, sf::Lines);
                                window.draw(layoverLine2, 2, sf::Lines);

                                connectingFlightFound = true;
                                break;
                            }
                            layoverFlight = layoverFlight->next;
                        }
                    }
                    if (connectingFlightFound) break;
                    connection = connection->next;
                }
            }

            // Handle mouse hover and display tooltip
            sf::Vector2i mousePos = sf::Mouse::getPosition(window);
            if (startNode.getGlobalBounds().contains(sf::Vector2f(mousePos)))
            {
                tooltipText.setFont(font);
                tooltipText.setString("Start City: " + std::string(start) + "\nDirect Flight Available: " + (directFlightFound ? "Yes" : "No"));
                tooltipText.setCharacterSize(14);
                tooltipText.setFillColor(sf::Color::White);
                tooltipText.setPosition(mousePos.x + 10, mousePos.y + 10);
                window.draw(tooltipText);
            }
            else if (destNode.getGlobalBounds().contains(sf::Vector2f(mousePos)))
            {
                tooltipText.setFont(font);
                tooltipText.setString("Destination City: " + std::string(end) + "\nDirect Flight Available: " + (directFlightFound ? "Yes" : "No"));
                tooltipText.setCharacterSize(14);
                tooltipText.setFillColor(sf::Color::White);
                tooltipText.setPosition(mousePos.x + 10, mousePos.y + 10);
                window.draw(tooltipText);
            }
            else if (directFlightFound && mousePos.x >= startCityPos.x && mousePos.x <= endCityPos.x &&
                mousePos.y >= startCityPos.y && mousePos.y <= endCityPos.y)
            {
                tooltipText.setFont(font);
                tooltipText.setString("Flight Details: Direct flight from " + std::string(start) + " to " + std::string(end) + "\nDate: " + std::string(ddate));
                tooltipText.setCharacterSize(14);
                tooltipText.setFillColor(sf::Color::White);
                tooltipText.setPosition(mousePos.x + 10, mousePos.y + 10);
                window.draw(tooltipText);
            }

            // Display a message if no flights are found
            if (!directFlightFound && !connectingFlightFound)
            {
                sf::Text noFlightMessage;
                noFlightMessage.setFont(font);
                noFlightMessage.setString("No flights available.");
                noFlightMessage.setCharacterSize(18);
                noFlightMessage.setFillColor(sf::Color::Red);
                noFlightMessage.setPosition(300, 500);
                window.draw(noFlightMessage);
            }

            window.display();
        }
    }
    void Layover_Graphics(const char* start, const char* end, const char* date)
    {
        // Find indices of the start and end cities
        int originIndex = findCityIndex(start);
        int destIndex = findCityIndex(end);

        if (originIndex == -1 || destIndex == -1)
        {
            cout << "Error! Unable to find the specified cities in the system." << endl;
            return;
        }

        // SFML Setup
        sf::RenderWindow window(sf::VideoMode(800, 600), "Flight Booking Visualization");
        sf::Font font;
        if (!font.loadFromFile("C:\Visual Studio kaam\FLIGHT SIMULATION - 23i - 2044, 23i - 2071, 23i--2103\\PlayfairDisplay - Regular.ttf"))
        {
            cerr << "Error: Unable to load font." << endl;
            return;
        }

        // City Nodes and Labels
        sf::CircleShape startNode(12), destNode(12), layoverNode(12);
        sf::Text startLabel, destLabel, layoverLabel, tooltipText;

        // Position of cities (hardcoded for simplicity)
        sf::Vector2f startCityPos(200, 300);
        sf::Vector2f endCityPos(600, 300);
        sf::Vector2f layoverCityPos(400, 300); // Midpoint for layover city

        // Setup the starting city node and label
        startNode.setFillColor(sf::Color::Green);
        startNode.setPosition(startCityPos);
        startLabel.setFont(font);
        startLabel.setString(start);
        startLabel.setCharacterSize(14);
        startLabel.setFillColor(sf::Color::White);
        startLabel.setPosition(startCityPos.x - 20, startCityPos.y - 30);

        // Setup the destination city node and label
        destNode.setFillColor(sf::Color::Green);
        destNode.setPosition(endCityPos);
        destLabel.setFont(font);
        destLabel.setString(end);
        destLabel.setCharacterSize(14);
        destLabel.setFillColor(sf::Color::White);
        destLabel.setPosition(endCityPos.x - 20, endCityPos.y - 30);

        bool directFlightFound = false;
        bool connectingFlightFound = false;

        Node* directFlight = adjLists[originIndex].head;
        Node* connection = adjLists[originIndex].head;

        while (window.isOpen())
        {
            sf::Event event;
            while (window.pollEvent(event))
            {
                if (event.type == sf::Event::Closed)
                    window.close();
            }

            window.clear();

            // Draw start and destination cities
            window.draw(startNode);
            window.draw(startLabel);
            window.draw(destNode);
            window.draw(destLabel);

            // Check for direct flights
            while (directFlight != nullptr)
            {
                if (directFlight->flightData.destination == end && directFlight->flightData.travel_date == date)
                {
                    // Draw direct flight line
                    sf::Vertex directLine[] = {
                        sf::Vertex(sf::Vector2f(startCityPos.x + 12, startCityPos.y + 12), sf::Color::White),
                        sf::Vertex(sf::Vector2f(endCityPos.x + 12, endCityPos.y + 12), sf::Color::White)
                    };
                    window.draw(directLine, 2, sf::Lines);
                    directFlightFound = true;
                    break;
                }
                directFlight = directFlight->next;
            }

            // Check for connecting flights if no direct flight is found
            if (!directFlightFound)
            {
                while (connection != nullptr)
                {
                    int layoverIndex = findCityIndex(connection->flightData.destination);
                    if (layoverIndex != -1 && connection->flightData.travel_date == date)
                    {
                        Node* layoverFlight = adjLists[layoverIndex].head;
                        while (layoverFlight != nullptr)
                        {
                            if (layoverFlight->flightData.destination == end && layoverFlight->flightData.travel_date == date)
                            {
                                // Draw layover city and label
                                layoverNode.setFillColor(sf::Color::Yellow);
                                layoverNode.setPosition(layoverCityPos);
                                layoverLabel.setFont(font);
                                layoverLabel.setString(connection->flightData.destination);
                                layoverLabel.setCharacterSize(14);
                                layoverLabel.setFillColor(sf::Color::White);
                                layoverLabel.setPosition(layoverCityPos.x - 20, layoverCityPos.y - 30);

                                window.draw(layoverNode);
                                window.draw(layoverLabel);

                                // Draw lines for layover flight with color change
                                sf::Vertex layoverLine1[] = {
                                    sf::Vertex(sf::Vector2f(startCityPos.x + 12, startCityPos.y + 12), sf::Color::Yellow),
                                    sf::Vertex(sf::Vector2f(layoverCityPos.x + 12, layoverCityPos.y + 12), sf::Color::Yellow)
                                };
                                sf::Vertex layoverLine2[] = {
                                    sf::Vertex(sf::Vector2f(layoverCityPos.x + 12, layoverCityPos.y + 12), sf::Color::Yellow),
                                    sf::Vertex(sf::Vector2f(endCityPos.x + 12, endCityPos.y + 12), sf::Color::Yellow)
                                };

                                window.draw(layoverLine1, 2, sf::Lines);
                                window.draw(layoverLine2, 2, sf::Lines);

                                connectingFlightFound = true;
                                break;
                            }
                            layoverFlight = layoverFlight->next;
                        }
                    }
                    if (connectingFlightFound) break;
                    connection = connection->next;
                }
            }

            // Handle mouse hover and display tooltip
            sf::Vector2i mousePos = sf::Mouse::getPosition(window);
            if (startNode.getGlobalBounds().contains(sf::Vector2f(mousePos)))
            {
                tooltipText.setFont(font);
                tooltipText.setString("Start City: " + std::string(start) + "\nDirect Flight Available: " + (directFlightFound ? "Yes" : "No"));
                tooltipText.setCharacterSize(14);
                tooltipText.setFillColor(sf::Color::White);
                tooltipText.setPosition(mousePos.x + 10, mousePos.y + 10);
                window.draw(tooltipText);
            }
            else if (destNode.getGlobalBounds().contains(sf::Vector2f(mousePos)))
            {
                tooltipText.setFont(font);
                tooltipText.setString("Destination City: " + std::string(end) + "\nDirect Flight Available: " + (directFlightFound ? "Yes" : "No"));
                tooltipText.setCharacterSize(14);
                tooltipText.setFillColor(sf::Color::White);
                tooltipText.setPosition(mousePos.x + 10, mousePos.y + 10);
                window.draw(tooltipText);
            }
            else if (layoverNode.getGlobalBounds().contains(sf::Vector2f(mousePos)))
            {
                // Ensure time difference is calculated using the correct flight data
                std::string timeDifference = connection->flightData.getTimeDifference(connection->flightData.flying_time, connection->flightData.landing_time);

                // Correct concatenation of the tooltip string
                tooltipText.setFont(font);
                tooltipText.setString("Layover City: " + std::string(connection->flightData.destination) +
                    "\nDeparture: " + std::string(connection->flightData.flying_time) +
                    "\nArrival Time: " + std::string(connection->flightData.landing_time) +
                    "\nLayover Duration: " + timeDifference);

                tooltipText.setCharacterSize(14);
                tooltipText.setFillColor(sf::Color::White);
                tooltipText.setPosition(mousePos.x + 10, mousePos.y + 10);
                window.draw(tooltipText);
            }

            else if (directFlightFound && mousePos.x >= startCityPos.x && mousePos.x <= endCityPos.x &&
                mousePos.y >= startCityPos.y && mousePos.y <= endCityPos.y)
            {
                tooltipText.setFont(font);
                tooltipText.setString("Flight Details: Direct flight from " + std::string(start) + " to " + std::string(end) + "\nDate: " + std::string(date));
                tooltipText.setCharacterSize(14);
                tooltipText.setFillColor(sf::Color::White);
                tooltipText.setPosition(mousePos.x + 10, mousePos.y + 10);
                window.draw(tooltipText);
            }

            // Display a message if no flights are found
            if (!directFlightFound && !connectingFlightFound)
            {
                sf::Text noFlightMessage;
                noFlightMessage.setFont(font);
                noFlightMessage.setString("No flights available.");
                noFlightMessage.setCharacterSize(18);
                noFlightMessage.setFillColor(sf::Color::Red);
                noFlightMessage.setPosition(300, 500);
                window.draw(noFlightMessage);
            }

            window.display();
        }
    }

    ~Graph()
    {
        delete[] adjLists;
        delete[] hotels;
        delete[] cityNames;
    }
};
//-----------------------------------------------------------------------------------------------------

//Function 6 with linked list:::::
class RouteSegment {
public:
    char origin[50];
    char destination[50];
    char travel_date[50];
    char flying_time[50];
    char landing_time[50];
    int ticket_price;
    char airline_name[50];
    RouteSegment* next;

    RouteSegment(const char* orig, const char* dest, const char* date, const char* flyTime, const char* landTime, int price, const char* airline)
    {
        strcpy_s(origin, sizeof(origin), orig);
        strcpy_s(destination, sizeof(destination), dest);
        strcpy_s(travel_date, sizeof(travel_date), date);
        strcpy_s(flying_time, sizeof(flying_time), flyTime);
        strcpy_s(landing_time, sizeof(landing_time), landTime);
        ticket_price = price;
        strcpy_s(airline_name, sizeof(airline_name), airline);
        next = nullptr;
    }
};

// LinkedList Class
class LinkedList
{
private:
    RouteSegment* head;
    RouteSegment* tail;

public:
    // Constructor
    LinkedList() : head(nullptr), tail(nullptr) {}

    // Function to add a segment
    void addSegment(const char* origin, const char* destination, const char* travel_date,
        const char* flying_time, const char* landing_time, int ticket_price, const char* airline_name)
    {
        RouteSegment* newSegment = new RouteSegment(origin, destination, travel_date, flying_time, landing_time, ticket_price, airline_name);

        if (!head) {
            head = tail = newSegment;
        }
        else {
            tail->next = newSegment;
            tail = newSegment;
        }

        cout << "Segment added: " << origin << " -> " << destination << "\n";
        //visualize();
    }

    // Function to remove a segment by origin and destination
    void removeSegment(const char* origin, const char* destination)
    {
        RouteSegment* temp = head;
        RouteSegment* prev = nullptr;

        while (temp) {
            if (strcmp(temp->origin, origin) == 0 && strcmp(temp->destination, destination) == 0) {
                if (temp == head) {
                    head = head->next;
                }
                else {
                    prev->next = temp->next;
                }

                if (temp == tail) {
                    tail = prev;
                }

                delete temp;
                cout << "Segment removed: " << origin << " -> " << destination << "\n";
                return;
            }
            prev = temp;
            temp = temp->next;
        }
        // cout << "Segment not found: " << origin << " -> " << destination << "\n";
        visualize();
    }

    // Function to modify a segment's details
    void modifySegment(const char* origin, const char* destination, const char* newDate,
        const char* newFlyingTime, const char* newLandingTime, int newPrice, const char* newAirline)
    {
        RouteSegment* temp = head;

        while (temp)
        {
            if (strcmp(temp->origin, origin) == 0 && strcmp(temp->destination, destination) == 0)
            {
                strcpy_s(temp->travel_date, sizeof(temp->travel_date), newDate);
                strcpy_s(temp->flying_time, sizeof(temp->flying_time), newFlyingTime);
                strcpy_s(temp->landing_time, sizeof(temp->landing_time), newLandingTime);
                temp->ticket_price = newPrice;
                strcpy_s(temp->airline_name, sizeof(temp->airline_name), newAirline);

                cout << "Segment modified: " << origin << " -> " << destination << "\n";
                return;
            }
            temp = temp->next;
        }
        //  cout << "Segment not found: " << origin << " -> " << destination << "\n";

        visualize();
    }

    // Function to display all segments in the route
    void displayRoute()
    {
        RouteSegment* temp = head;

        if (!temp) {
            cout << "No segments in the route.\n";
            return;
        }

        cout << "\nRoute Details:\n";
        while (temp) {
            cout << temp->origin << " -> " << temp->destination
                << " | Date: " << temp->travel_date
                << " | Flying Time: " << temp->flying_time
                << " | Landing Time: " << temp->landing_time
                << " | Price: $" << temp->ticket_price
                << " | Airline: " << temp->airline_name << "\n";
            temp = temp->next;
        }

        visualize();
    }

    // Visualization function
    void visualize() {
        // SFML Setup
        sf::RenderWindow window(sf::VideoMode(11000, 800), "Route Visualization");
        window.setFramerateLimit(80);

        sf::Font font;
        if (!font.loadFromFile("C:\Visual Studio kaam\FLIGHT SIMULATION - 23i - 2044, 23i - 2071, 23i--2103\\PlayfairDisplay - Regular.ttf"))
        {
            std::cout << "Error loading font\n";
            return;
        }

        while (window.isOpen()) {
            sf::Event event;
            while (window.pollEvent(event)) {
                if (event.type == sf::Event::Closed)
                    window.close();
            }

            // Clear the window
            window.clear(sf::Color::Black);

            // Draw the route visualization (linked list of flights)
            RouteSegment* temp = head;
            float x = 50.0f, y = 100.0f;
            float offsetX = 200.0f;  // Adjust distance between nodes (cities)

            while (temp) {
                // Draw origin circle (red for each city)
                sf::CircleShape originNode(30.0f);
                originNode.setFillColor(sf::Color::Red);
                originNode.setPosition(x, y);
                window.draw(originNode);

                // Draw origin text (city name)
                sf::Text originText(temp->origin, font, 16);
                originText.setFillColor(sf::Color::White);
                originText.setPosition(x + 5, y - 20);
                window.draw(originText);

                // Display Flight info as a tooltip on hover
                sf::Text flightInfo("Flight: " + std::string(temp->origin) + " -> " + std::string(temp->destination) +
                    "\nPrice: $" + std::to_string(temp->ticket_price) +
                    "\nAirline: " + std::string(temp->airline_name), font, 14);
                flightInfo.setFillColor(sf::Color::Yellow);
                flightInfo.setPosition(x + 5, y + 70); // Position below the node
                window.draw(flightInfo);

                // Move for next node (next city)
                x += offsetX;

                if (temp->next) {
                    // Draw line (edge) connecting origin and destination
                    sf::Vertex line[] = {
                        sf::Vertex(sf::Vector2f(x - offsetX / 2, y + 30.0f), sf::Color::White),
                        sf::Vertex(sf::Vector2f(x - 50.0f, y + 30.0f), sf::Color::White)
                    };
                    window.draw(line, 2, sf::Lines);
                }

                temp = temp->next;
            }

            // Display everything
            window.display();
        }
    }

};
//------------------------------------------------QUEUE------------------------------------------------------------------------------------------
class Queue {
public:
    Node* front;
    Node* rear;
    int numitems;

public:
    Queue() {
        front = NULL;
        rear = NULL;
        numitems = 0;
    }

    ~Queue() {
        Clear();
    }

    bool isEmpty() {
        return numitems == 0;
    }

    void Enqueue(Flight flight) {
        Node* temp = new Node;
        temp->flightData = flight;

        temp->next = NULL;

        if (front == NULL && rear == NULL) { // Empty list
            front = rear = temp;
        }
        else { // Non-empty list
            rear->next = temp;
            rear = temp;
        }
        numitems++;
    }

    void Dequeue() {
        if (isEmpty()) {
            cout << "Underflow\n";
            return;
        }
        Node* temp = front;
        front = front->next;
        delete temp;
        numitems--;
        if (front == NULL) {
            rear = NULL; // If the list becomes empty, reset the rear pointer
        }
    }

    void print() {
        for (Node* temp = front; temp != NULL; temp = temp->next) {
            cout << "Flight from " << temp->flightData.origin << " to " << temp->flightData.destination << endl;
        }
    }

    void Clear() {
        while (front != NULL) {
            Node* temp = front;
            front = front->next;
            delete temp;
        }
        rear = NULL;
        numitems = 0;
    }

    Node* getFront() {
        return front;
    }

    Node* getRear() {
        return rear;
    }

    int size() {
        return numitems;
    }

    void Layover(Flight flights[], int size, const string& origin, const string& destination, const string& date) {
        bool foundDirect = false;
        bool foundConnection = false;

        // Queue to manage the flight connections
        Queue flightQueue;

        // First, check for direct flights
        for (int i = 0; i < size; i++) {
            if (flights[i].origin == origin && flights[i].destination == destination && flights[i].isSameDay(date)) {
                cout << "Direct flight found from " << origin << " to " << destination << " on " << date << endl;
                cout << "Airline: " << flights[i].airline_name << " | Ticket Price: " << flights[i].ticket_price << endl;
                cout << "Flight Duration: " << flights[i].getFlightDuration() / 60 << " hours and " << flights[i].getFlightDuration() % 60 << " minutes" << endl;
                cout << "No Connecting Flight.Hence No Layover Time";
                foundDirect = true;
                break; // If direct flight found, break out of loop
            }
        }

        // If no direct flight found, look for connecting flights
        if (!foundDirect) {
            cout << "No direct flight found. Searching for connecting flights..." << endl;

            // Enqueue all the flights from the origin airport
            for (int i = 0; i < size; i++) {
                if (flights[i].origin == origin && flights[i].isSameDay(date)) {
                    flightQueue.Enqueue(flights[i]);
                }
            }

            // Process the queue to find valid connecting flights
            while (!flightQueue.isEmpty()) {
                Flight firstFlight = flightQueue.getFront()->flightData;  // Dequeue the first flight
                flightQueue.Dequeue();

                for (int j = 0; j < size; j++) {
                    if (flights[j].origin == firstFlight.destination && flights[j].destination == destination && flights[j].isSameDay(date)) {
                        int landingMinutes = firstFlight.getLandingMinutes();
                        int nextFlightFlyingMinutes = flights[j].getFlyingMinutes();

                        // Check if layover is valid
                        if (Flight::isLayoverValid(landingMinutes, nextFlightFlyingMinutes)) {
                            foundConnection = true;

                            int flight1Duration = firstFlight.getFlightDuration();
                            int flight2Duration = flights[j].getFlightDuration();

                            int layoverDuration = Flight::getTimeDifference(firstFlight.getLandingMinutes(), flights[j].getFlyingMinutes());

                            cout << "Connecting flight found: " << firstFlight.origin << " -> " << firstFlight.destination
                                << " -> " << flights[j].destination << endl;
                            cout << "Flight 1: " << firstFlight.origin << " to " << firstFlight.destination << " | Airline: "
                                << firstFlight.airline_name << " | Ticket Price: " << firstFlight.ticket_price << " | Flight Duration: "
                                << flight1Duration / 60 << " hours and " << flight1Duration % 60 << " minutes" << endl;
                            cout << "Flight 2: " << flights[j].origin << " to " << flights[j].destination << " | Airline: "
                                << flights[j].airline_name << " | Ticket Price: " << flights[j].ticket_price << " | Flight Duration: "
                                << flight2Duration / 60 << " hours and " << flight2Duration % 60 << " minutes" << endl;

                            cout << "Layover Duration: " << layoverDuration / 60 << " hours and " << layoverDuration % 60 << " minutes" << endl;
                        }
                    }
                }
            }
        }

        if (!foundDirect && !foundConnection) {
            cout << "No connecting flight found for " << origin << " to " << destination << " on " << date << endl;
        }
    }



};
//-----------------------------------------------------------------------------------------------------------------------------------------------
// Graphical Query and Display of Subgraph
class GraphicalQuery
{
public:
    void queryAndDisplaySubgraph(Graph& g, const char* cityName)
    {
        int cityIndex = g.findCityIndex(cityName);
        if (cityIndex == -1)
        {
            std::cout << "City not found!" << std::endl;
            return;
        }

        Graph subgraph(g.maxVertices);
        g.generateSubgraph(cityIndex, subgraph);

        // Create an SFML window
        sf::RenderWindow window(sf::VideoMode(100, 600), "Flight Routes");

        // Load font for text display
        sf::Font font;
        if (!font.loadFromFile("C:\Visual Studio kaam\FLIGHT SIMULATION - 23i - 2044, 23i - 2071, 23i--2103\\PlayfairDisplay - Regular.ttf"))
        {
            std::cerr << "Error loading font\n";
            return;
        }

        while (window.isOpen()) 
        {
            sf::Event event;
            while (window.pollEvent(event)) {
                if (event.type == sf::Event::Closed)
                    window.close();
            }

            window.clear();

            // Draw active routes (edges) between cities as dashed lines
            for (int i = 0; i < subgraph.maxVertices; i++)
            {
                Node* temp = subgraph.adjLists[i].head;
                while (temp != nullptr)
                {
                    // Get source and destination positions
                    float x1 = 120.f * i;
                    float y1 = 170.f;  // Placeholder position for city i
                    int destIndex = g.findCityIndex(temp->flightData.destination); // Assuming destinationIndex is stored
                    float x2 = 120.f * destIndex;  // Placeholder position for destination city
                    float y2 = 170.f;  // Same placeholder

                    // Draw dashed line (representing the flight route)
                    drawDashedLine(window, x1, y1, x2, y2);

                    temp = temp->next;
                }

                // Draw the circle for the current city
                sf::CircleShape cityNode(10.f); // Circle size
                cityNode.setFillColor(sf::Color::Green);

                // Position the circle slightly above the dashed line
                float circleX = 100.f * i;    // Align horizontally
                float circleY = 200.f - 30.f; // Slightly above the dashed line
                cityNode.setPosition(circleX - cityNode.getRadius(), circleY - cityNode.getRadius());

                window.draw(cityNode);

                // Display city name
                sf::Text cityText;      //Variable initialization ho rhi hai
                cityText.setFont(font);
                cityText.setString("City " + to_string(i + 1));  // Replace with actual city name
                cityText.setCharacterSize(14);
                cityText.setFillColor(sf::Color::White);
                cityText.setStyle(sf::Text::Italic); // Bold for emphasis
                cityText.setOutlineColor(sf::Color::Black); // Black outline for contrast
                cityText.setPosition(100.f * i - 20.f, 150.f + 40.f);  // Positioning below the city circle
                window.draw(cityText);
            }

            // Optionally, display flight details as text near cities
            for (int i = 0; i < subgraph.maxVertices; i++)
            {
                Node* temp = subgraph.adjLists[i].head;
                int flightOffset = 0; // Offset to stagger text vertically

                while (temp != nullptr)
                {
                    // Display the flight details as text near the cities
                    float x1 = 180.f * i;     // X-position based on city index
                    float y1 = 150.f;         // Base Y-position for city i
                    sf::Text flightText;
                    flightText.setFont(font);
                    flightText.setString("Flight: " + std::string(temp->flightData.origin) + " -> " + std::string(temp->flightData.destination));
                    flightText.setCharacterSize(16);
                    flightText.setFillColor(sf::Color::Yellow);
                    flightText.setStyle(sf::Text::Bold); // Bold for emphasis
                    flightText.setOutlineColor(sf::Color::Black); // Black outline for contrast
                    flightText.setOutlineThickness(1.f); // Add a slight border

                    // Position the text with a vertical offset for each flight
                    flightText.setPosition(x1 + 80.f, y1 + 100.f + flightOffset);
                    window.draw(flightText);

                    // Increase the offset for the next flight
                    flightOffset += 20; // Adjust spacing between flight texts (20 pixels)

                    temp = temp->next;
                }
            }


            window.display();
            window.clear();
        }
    }

    // Function to draw dashed lines (used for active routes)
    void drawDashedLine(sf::RenderWindow& window, float x1, float y1, float x2, float y2)
    {
        float dashLength = 10.f;  // Length of each dash
        float gapLength = 5.f;    // Gap between dashes
        float totallength = dashLength + gapLength;

        //Caculate total length
        float dx = x2 - x1;
        float dy = y2 - y1;
        float lineLength = std::sqrt(dx * dx + dy * dy);

        float unitX = dx / lineLength;
        float unitY = dy / lineLength;

        int numDashes = static_cast<int>(lineLength / totallength);

        sf::Vertex line[2];
        for (int i = 0; i < numDashes; ++i)
        {
            // Calculate start and end of each dash
            float startX = x1 + i * totallength * unitX;
            float startY = y1 + i * totallength * unitY;
            float endX = startX + dashLength * unitX;
            float endY = startY + dashLength * unitY;

            line[0] = sf::Vertex(sf::Vector2f(startX, startY), sf::Color::White);
            line[1] = sf::Vertex(sf::Vector2f(endX, endY), sf::Color::White);
            window.draw(line, 2, sf::Lines);
        }
    }
};
//-----------------------------------------------------------------------------------------------------

// Function to load flight data from a file into arrays
void loadFlightsFromFile(const string& fileName, string origins[], string destinations[], string travel_dates[],
    string flying_times[], string landing_times[], int ticket_prices[], string airline_names[],
    int& flightCount, LinkedList& routeManager)
{
    ifstream file(fileName);

    if (!file)
    {
        cerr << "Unable to open file: " << fileName << "\n";
        return;
    }

    string line;
    int index = 0;

    // Read each line of the file
    while (getline(file, line))
    {
        stringstream ss(line);
        string origin, destination, travel_date, flying_time, landing_time, airline_name;
        int ticket_price;

        // Read flight details from the file
        ss >> origin >> destination >> travel_date >> flying_time >> landing_time >> ticket_price >> airline_name;

        // Store flight data in arrays
        origins[index] = origin;
        destinations[index] = destination;
        travel_dates[index] = travel_date;
        flying_times[index] = flying_time;
        landing_times[index] = landing_time;
        ticket_prices[index] = ticket_price;
        airline_names[index] = airline_name;

        // Add flight details to the linked list
        routeManager.addSegment(origin.c_str(), destination.c_str(), travel_date.c_str(), flying_time.c_str(),
            landing_time.c_str(), ticket_price, airline_name.c_str());

        index++;
        if (index == 105) break; // Limit to 105 flights
    }
    flightCount = index;

    file.close();
    cout << "Flights loaded successfully from " << fileName << "\n";
}


void function6call()
{
    // Flight data arrays
    string origins[105];
    string destinations[105];
    string travel_dates[105];
    string flying_times[105];
    string landing_times[105];
    int ticket_prices[105];
    string airline_names[105];
    int flightCount = 0;
    LinkedList routeManager;
    // Load flight data from file
    loadFlightsFromFile("Flights.txt", origins, destinations, travel_dates, flying_times, landing_times, ticket_prices, airline_names, flightCount, routeManager);
    //LinkedList routeManager;
    bool flag = true;
    int choice;

    while (flag)
    {
        cout << "\n--- Multi-Leg Journey Manager ---\n";
        cout << "1. Add a Segment\n";
        cout << "2. Remove a Segment\n";
        cout << "3. Modify a Segment\n";
        cout << "4. Display Current Route\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1: {
            // Add a new segment
            char origin[50], destination[50], travel_date[50], flying_time[50], landing_time[50], airline_name[50];
            int ticket_price;

            cout << "Enter origin: ";
            cin >> origin;
            cout << "Enter destination: ";
            cin >> destination;
            cout << "Enter travel date: ";
            cin >> travel_date;
            cout << "Enter flying time: ";
            cin >> flying_time;
            cout << "Enter landing time: ";
            cin >> landing_time;
            cout << "Enter ticket price (in USD): ";
            cin >> ticket_price;
            cout << "Enter airline name: ";
            cin >> airline_name;

            routeManager.addSegment(origin, destination, travel_date, flying_time, landing_time, ticket_price, airline_name);
            routeManager.visualize();
            cout << "Segment added successfully.\n";
            break;
        }
        case 2: {
            // Remove an existing segment
            char origin[50], destination[50];
            cout << "Enter origin of the segment to remove: ";
            cin >> origin;
            cout << "Enter destination of the segment to remove: ";
            cin >> destination;

            routeManager.removeSegment(origin, destination);
            //routeManager.visualize();
            break;
        }
        case 3: {
            // Modify an existing segment
            char origin[50], destination[50], newDate[50], newFlyingTime[50], newLandingTime[50], newAirline[50];
            int newPrice;

            cout << "Enter origin of the segment to modify: ";
            cin >> origin;
            cout << "Enter destination of the segment to modify: ";
            cin >> destination;
            cout << "Enter new travel date: ";
            cin >> newDate;
            cout << "Enter new flying time: ";
            cin >> newFlyingTime;
            cout << "Enter new landing time: ";
            cin >> newLandingTime;
            cout << "Enter new ticket price (in USD): ";
            cin >> newPrice;
            cout << "Enter new airline name: ";
            cin >> newAirline;

            routeManager.modifySegment(origin, destination, newDate, newFlyingTime, newLandingTime, newPrice, newAirline);
            // routeManager.visualize();
            break;
        }
        case 4:
            // Display the current route
            routeManager.displayRoute();
            // routeManager.visualize();
            break;
        case 5:
            // Exit the program
            cout << "Exiting the program. Thank you!\n";
            flag = false;
            break;
        default:
            cout << "Invalid choice. Please try again.\n";
            break;
        }
    }
}
//------------------------------------------------------- BONUS FUNCTION --------------------------------------------------------------
void flightTriviaGame()
{
    int score = 0;
    string answer;

    cout << "\nWelcome to the Flight Trivia Game! Let's test your knowledge about airlines and cities!\n";
    cout << "You will get 3 questions. Answer them correctly to score points.\n\n";

    // Question 1
    cout << "Question 1: Which airline is known for its 'Fly Emirates' slogan? \n";
    cout << "a) Emirates\nb) Qatar Airways\nc) Air India\nd) American Airlines\n";
    cin >> answer;      //select option

    if (answer == "a" || answer == "A")
    {
        score++;
        cout << "Correct! Well done '-(^_^)-' .\n\n";
    }
    else
    {
        cout << "Wrong! The correct answer is 'Emirates' '-(0_0)-' .\n\n";
    }

    // Question 2
    cout << "Question 2: Which city is known as the 'Big Apple'? \n";
    cout << "a) London\nb) Paris\nc) New York\nd) Tokyo\n";
    cin >> answer;

    if (answer == "c" || answer == "C")
    {
        score++;
        cout << "Correct! Well done '-(^_^)-' .\n\n";
    }
    else
    {
        cout << "Wrong! The correct answer is 'New York' '-(0_0)-' .\n\n";
    }

    // Question 3
    cout << "Question 3: What is the capital city of Japan? \n";
    cout << "a) Beijing\nb) Seoul\nc) Tokyo\nd) Bangkok\n";
    cin >> answer;

    if (answer == "c" || answer == "C")
    {
        score++;
        cout << "Correct! Well done '-(^_^)-' .\n\n";
    }
    else
    {
        cout << "Wrong! The correct answer is 'Tokyo' '-(0_0)-' .\n\n";
    }

    // Display the final score
    cout << "You scored " << score << " out of 3!\n";
    if (score == 3)
    {
        cout << "Awesome! You're a travel expert! '-(^_^)-' \n";
    }
    else if (score == 2)
    {
        cout << "Good job! You're almost there! :) \n";
    }
    else
    {
        cout << "Better luck next time! Keep learning! '-(0_0)-' \n";
    }

    cout << endl << endl;
}


int main()
{
    //----------------------------------------------- FILE HANDLING START FROM HERE ---------------------------------------------------
    // Flight arrays
    string origins[105];
    string destinations[105];
    string travel_dates[105];
    string flying_times[105];
    string landing_times[105];
    int ticket_price[105];
    string airline_names[105];

    // Hotel arrays
    string Hotel_city[11];
    int Hotel_price[11];
    Hotel hotels[11];

    // Array to store objects
    Flight flights[105];

    // Open the flight data file
    ifstream file("Flights.txt");

    if (!file)
    {
        cerr << "Unable to open file Flights.txt";
        return 1;
    }

    string line;
    int index = 0;

    // Read the flight data from file
    while (getline(file, line))
    {
        stringstream ss(line);

        ss >> origins[index];
        ss >> destinations[index];
        ss >> travel_dates[index];
        ss >> flying_times[index];
        ss >> landing_times[index];
        ss >> ticket_price[index];
        ss >> airline_names[index];

        index++;
        if (index == 105)
        {
            break;
        }
    }
    file.close();
    int flightCount = index;
    // Open the hotel charges file
    ifstream hotel_file("HotelCharges_perday.txt");

    if (!hotel_file)
    {
        cerr << "Unable to open file HotelCharges_perday.txt";
        return 1;
    }

    int hotel_index = 0;

    // Read the hotel data from file
    while (getline(hotel_file, line))
    {
        stringstream ss(line);

        ss >> Hotel_city[hotel_index];
        ss >> Hotel_price[hotel_index];

        hotel_index++;
        if (hotel_index == 11)
        {
            break;
        }
    }
    hotel_file.close();

    // Create an array of Flight objects
    for (int i = 0; i < 105; ++i)
    {
        flights[i] = Flight(origins[i], destinations[i], travel_dates[i],
            flying_times[i], landing_times[i], ticket_price[i], airline_names[i]);
    }

    //----------------------------------------------- FILE HANDLING END FROM HERE ---------------------------------------------------

   //----------------------------------------------- ADDING CITIES AS VERTICES AND FLIGHTS AS EDGES ---------------------------------------------------
    const int cityCount = sizeof(Hotel_city) / sizeof(Hotel_city[0]);
    // Create the graph to store cities and flights
    int vert = 11;

    Graph g1(vert);

    // Adding cities to the graph
    for (int i = 0; i < 11; ++i)  // Assuming we add 5 cities for example
    {
        g1.addHotel(Hotel_city[i], Hotel_price[i]);
    }

    // Inserting flights between cities
    for (int i = 0; i < 105; ++i)  // Insert all flights
    {
        int originIndex = g1.findCityIndex(flights[i].origin);
        int destIndex = g1.findCityIndex(flights[i].destination);

        if (originIndex != -1 && destIndex != -1)  // Ensure valid city indices
        {
            g1.insertFlight(originIndex, destIndex, flights[i]);
        }
    }
    //-----------------------------------------------QUEUE LAYOVER SYSTEM------------------------------------------------------------
    Queue q;
    for (int i = 0;i < 105;i++)
    {
        q.Enqueue(flights[i]);
    }
    //----------------------------------------------- MENU DRIVEN START FROM HERE ---------------------------------------------------
    bool flag = true;
    int choice;
    string start, end, date;      //for booking my flight part
    string source, Destination, ddate;
    string Transitcity, airline;
    cout << "\t*******************************************************************************************************" << endl;
    cout << "\t************                                                                           ****************\n";
    cout << "\t*******************          Welcome to SkyNAV AI - Path Visualizer :)            *********************\n";
    cout << "\t************                                                                           ****************\n";
    cout << "\t*******************************************************************************************************" << endl << endl;
    cout << "\n These our Flights :: \n" << endl;
    g1.showGraph();
    g1.graphicsForGraphWithTooltips(g1, Hotel_city, flights, flightCount, cityCount);       //This is also sort of some bonus may be :)

    while (flag)
    {
        cout << " How would you like me to help you?\n ";
        cout << "1) Flight Data Representation\n"
            << " 2) Flight Booking \n"
            << " 3) Shortest and Cheapest Route \n"
            << " 4) Custom Flight path and preferences \n"
            << " 5) Layover Management\n "
            << "6) Advanced Route Generation \n"
            << " 7) Graphical Query & Subgraph Generation \n"
            << " 8) Flight Trivia Game (Bonus!)\n "
            << " 9) Exit\n ";
        cout << " Answer :: ";
        cin >> choice;

        //now we will use switch statement then : 
        switch (choice)
        {
        case 1:
        {
            cout << "Enter the City you want to Travel from: ";
            cin >> source;
            cout << "Enter destination: ";
            cin >> Destination;
            cout << "Enter travel date (e.g. 1/12/2019): ";
            cin >> ddate;
            g1.SearchFlight(source, Destination, ddate);
            g1.graphicsForSelectedFlight(source.c_str(), Destination.c_str(), ddate.c_str());
        }
        break;
        case 2:
            //Flight Booking Feature start:
            cout << "\n Can you tell me about your origin :: ";
            cin >> start;
            cout << "\n Can you tell me about your destination :: ";
            cin >> end;
            cout << "\n Can you tell me your date for arrival :: ";
            cin >> date;
            //Function that will check starting point and ending point in flight.txt and then if match then phr woh uss ke direct and connecting points btaye ga:
            g1.BookFlight(start, end, date);
            g1.graphicsForSelectedFlight(start.c_str(), end.c_str(), date.c_str());
            break;
        case 3:
            //Cheapest and optimal path finding:
            cout << "\n Can you tell me about your origin :: ";
            cin >> start;
            cout << "\n Can you tell me about your destination :: ";
            cin >> end;

            int option;
            cout << "\nDo you want to find the route based on:\n";
            cout << "1) Shortest distance\n";
            cout << "2) Cheapest cost\n";
            cout << "Enter your choice: ";
            cin >> option;

            if (option == 1 || option == 2)
            {
                bool byCost = (option == 2);

                // Extract start and end indices
                int startIndex = g1.findCityIndex(start.c_str());
                int endIndex = g1.findCityIndex(end.c_str());

                if (startIndex == -1 || endIndex == -1) {
                    cout << "Invalid city names! Please check your input.\n";
                    break;
                }

                // Dynamically allocate arrays
                int* dist = new int[g1.maxVertices]; // Distance or cost
                int* prev = new int[g1.maxVertices]; // Previous nodes
                bool* visited = new bool[g1.maxVertices]; // Visited status

                // Initialize arrays
                for (int i = 0; i < g1.maxVertices; i++) {
                    dist[i] = INT_MAX;
                    prev[i] = -1;
                    visited[i] = false;
                }

                dist[startIndex] = 0; // Start node distance is 0

                // Run Dijkstra algorithm
                g1.dijkstra(start.c_str(), end.c_str(), byCost);

                // Visualize the results
                g1.visualizeDijkstra(dist, prev, visited, startIndex, endIndex);

                // Free dynamically allocated memory
                delete[] dist;
                delete[] prev;
                delete[] visited;

            }
            else
            {
                cout << "Invalid input! Please choose 1 or 2.\n";
            }

            break;

            break;
        case 4:
        {
            cout << "Enter the City you want to Travel from: ";
            cin >> source;
            cout << "Enter destination: ";
            cin >> Destination;
            cout << "Enter travel date (e.g. 1/12/2019): ";
            cin >> ddate;
            cout << "Enter your Transit City";
            cin >> Transitcity;
            cout << "Enter Airline (Qatar,Emirates,ANA)";
            cin >> airline;
            g1.FilterbyTransit(source, Destination, ddate, airline, Transitcity);
            g1.graphicsForTransit(source.c_str(), Destination.c_str(), ddate.c_str(), airline.c_str(), Transitcity.c_str());
        }
        break;
        case 5:
        {
            cout << "Enter the City you want to Travel from: ";
            cin >> source;
            cout << "Enter the City you want to Travel to: ";
            cin >> Destination;
            cout << "Enter the Date of Travel (dd-mm-yyyy): ";
            cin >> ddate;

            q.Layover(flights, 105, source, Destination, ddate);
            g1.Layover_Graphics(source.c_str(), Destination.c_str(), ddate.c_str());
        }
        break;
        case 6:
            //Advanced route with Linked list:
            cout << "\n Advanced Route :: \n\n ";
            function6call();
            cout << endl;
            break;
        case 7: {
            char cityname[20];
            std::cout << "\nCan you tell us city name: ";
            std::cin >> cityname;

            int index = g1.findCityIndex(cityname);
            if (index == -1) {
                std::cout << "City not found! Please try again.\n";
                break;
            }

            std::cout << "\nSubgraph for city " << cityname << " is:\n";
            Graph subgraph(g1.maxVertices);
            g1.generateSubgraph(index, subgraph);

            GraphicalQuery q1;
            q1.queryAndDisplaySubgraph(g1, cityname);
            break;
        }
        case 8:
            //creative functionality:
            flightTriviaGame(); // Start the trivia game
            break;
        case 9:
            cout << "Existing from Channel...........\n";
            flag = false;
            break;
        default:
            cout << "\t Invalid input, Please enter right input :) ";
            cout << endl;
            break;
        }
    }

    cout << "\t Thank you for coming :)" << endl
        << "\t I hope you will come again :) " << endl;

    // Show the graph with all cities and flights
   // g1.showGraph();

    return 0;
}